# Tab-Manager-Pro
Firefox addon to help YOU manage your out of control tabs!
